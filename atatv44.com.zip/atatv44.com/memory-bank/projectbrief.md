# ATATV44 - Kara Mizah Topluluğu Web Sitesi

## Proje Özeti
ATATV44, retro TV temalı bir arayüze sahip kara mizah topluluğu web sitesidir. Site, eski televizyon menülerinin nostaljik görünümünü modern web teknolojileriyle birleştirerek benzersiz bir kullanıcı deneyimi sunmayı amaçlamaktadır.

## Temel Gereksinimler
1. Retro TV arayüzü tasarımı
2. SEO optimizasyonu
3. Favicon entegrasyonu
4. TV efekt sesleri (kaydırma, açılış vs.)
5. Responsive tasarım
6. Discord entegrasyonu

## Hedefler
- Kullanıcılara nostaljik bir deneyim sunmak
- Topluluğun mizahi içeriklerini etkili bir şekilde sergilemek
- Google aramalarında görünürlüğü artırmak
- Kullanıcı etkileşimini ses efektleriyle zenginleştirmek 